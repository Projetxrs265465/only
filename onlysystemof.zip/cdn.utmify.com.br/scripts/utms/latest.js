(() => {
  "use strict";
  var e = {
      262: (e, t) => {
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.Random = void 0),
          (t.Random = class {
            static chooseOne(e) {
              return e[Math.floor(Math.random() * e.length)];
            }
          });
      },
      745: (e, t) => {
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.UnicodeHasher = void 0);
        class n {
          static encode(e) {
            return e.replace(/[0-9]/g, (e) => n.map[e]);
          }
          static decode(e) {
            const t = Object.values(n.map).join(""),
              r = new RegExp(`[${t}]`, "g");
            return e.replace(
              r,
              (e) => Object.keys(n.map).find((t) => n.map[t] === e) || ""
            );
          }
          static encodeAndInsert(e, t, r = 1) {
            const l = n.encode(e);
            return `${t.slice(0, r)}${l}${t.slice(r)}`;
          }
          static decodeAndExtract(e) {
            const t = Object.values(n.map).join(""),
              r = new RegExp(`[${t}]`, "g");
            let l = "";
            return (
              e.replace(r, (e) => {
                const t = Object.keys(n.map).find((t) => n.map[t] === e);
                return t && (l += t), e;
              }),
              "" !== l ? l : null
            );
          }
          static removeAllEncodedChars(e) {
            const t = Object.values(n.map).join(""),
              r = new RegExp(`[${t}]`, "g");
            return e.replace(r, "");
          }
        }
        (t.UnicodeHasher = n),
          (n.map = {
            0: "​",
            1: "‌",
            2: "‍",
            3: "⁠",
            4: "⁡",
            5: "⁢",
            6: "⁣",
            7: "⁤",
            8: "‪",
            9: "‬",
          });
      },
      202: (e, t, n) => {
        Object.defineProperty(t, "__esModule", { value: !0 }),
          (t.UrlRebuilder = void 0);
        const r = n(262),
          l = n(745);
        class i {
          static randomizePhoneNumberIfNecessary(e) {
            var t;
            const n = null !== (t = window.phones) && void 0 !== t ? t : [];
            if (0 === n.length) return e;
            const l = r.Random.chooseOne(n);
            return e.includes("phone=")
              ? i.withReplaceQueryParam(e, "phone", l)
              : e.includes("wa.me")
              ? `https://wa.me/${l}?${e.split("?")[1]}`
              : e;
          }
          static insertAdIdInWppUrl(e, t) {
            var n;
            const r =
                null !== (n = i.getQueryParams(e).get("text")) && void 0 !== n
                  ? n
                  : "Olá",
              o = t.replace(/[^0-9]/g, ""),
              a = l.UnicodeHasher.removeAllEncodedChars(r),
              s = l.UnicodeHasher.encodeAndInsert(o, a);
            return i.withReplaceQueryParam(e, "text", s);
          }
          static getAdId(e) {
            var t, n, r;
            const l =
              null !==
                (r =
                  null ===
                    (n =
                      null === (t = e.get("utm_content")) || void 0 === t
                        ? void 0
                        : t.split("::")) || void 0 === n
                    ? void 0
                    : n[0]) && void 0 !== r
                ? r
                : "";
            return l.includes("|") ? l.split("|")[1] : null;
          }
          static getQueryParams(e) {
            const t = e.split("?")[1];
            return new URLSearchParams(t);
          }
          static withReplaceQueryParam(e, t, n) {
            const r = e.split("?")[0],
              l = e.split("?")[1],
              i = new URLSearchParams(l);
            return i.set(t, n), `${r}?${i.toString()}`;
          }
          static removeSpecialCharacteres(e) {
            return e
              .normalize("NFD")
              .replace(/[\u0300-\u036f]/g, "")
              .replace(/[^\w\s-|]/gi, "")
              .replace(/\s/g, "");
          }
        }
        t.UrlRebuilder = i;
      },
    },
    t = {};
  function n(r) {
    var l = t[r];
    if (void 0 !== l) return l.exports;
    var i = (t[r] = { exports: {} });
    return e[r](i, i.exports, n), i.exports;
  }
  (() => {
    var e, t, r, l;
    const i = n(202);
    console.log("utms script loaded! 2.3.12");
    const o = {
      ignoreAllIframes: !!document.querySelector("[data-utmify-ignore-iframe]"),
      ignoreScriptRetry: !!document.querySelector("[data-utmify-ignore-retry]"),
      fastStart: !!document.querySelector("[data-utmify-fast-start]"),
      replacePlusSignal: !!document.querySelector("[data-utmify-plus-signal]"),
      isClickBank: !!document.querySelector("[data-utmify-is-click-bank]"),
      preventSubIds: !!document.querySelector("[data-utmify-prevent-subids]"),
      fixShopifyTheme: !!document.querySelector(
        "[data-utmify-fix-shopify-theme]"
      ),
      ignoreClasses:
        null ===
          (r =
            null ===
              (t =
                null ===
                  (e = document.querySelector(
                    "[data-utmify-ignore-classes]"
                  )) || void 0 === e
                  ? void 0
                  : e.getAttribute("data-utmify-ignore-classes")) ||
            void 0 === t
              ? void 0
              : t.split(" ")) || void 0 === r
          ? void 0
          : r.filter((e) => !!e),
      replaceLinks:
        null === (l = document.querySelector("[data-utmify-replace-links]")) ||
        void 0 === l
          ? void 0
          : l.getAttribute("data-utmify-replace-links"),
      isCartpanda: !!document.querySelector("[data-utmify-is-cartpanda]"),
      preventXcodSck: !!document.querySelector(
        "[data-utmify-prevent-xcod-sck]"
      ),
      preventClickIdsFallback: !!document.querySelector(
        "[data-utmify-prevent-click-ids-fallback]"
      ),
    };
    var a, s;
    !(function (e) {
      e.Doppus = "doppus";
    })(a || (a = {})),
      (function (e) {
        (e.PandaVideo = "pandavideo.com"),
          (e.YouTube = "youtube.com"),
          (e.EplayVideo = "eplay.video"),
          (e.Vimeo = "vimeo.com");
      })(s || (s = {}));
    const u = [
      "utm_source",
      "utm_campaign",
      "utm_medium",
      "utm_content",
      "utm_term",
    ];
    class c {
      static addUtmParametersToUrl(e) {
        const t = c.urlWithoutParams(e),
          n = c.paramsFromUrl(e),
          r = c.getUtmParameters(),
          l = new URLSearchParams();
        n.forEach((e, t) => l.append(t, e)),
          r.forEach((e, t) => l.append(t, e));
        const i = c.urlParametersWithoutDuplicates(l),
          a = c.simplifyParametersIfNecessary(t, i),
          s = o.replacePlusSignal
            ? a.toString().split("+").join("%20")
            : a.toString(),
          u = -1 === t.indexOf("?") ? "?" : "&";
        return `${t}${u}${s}`;
      }
      static urlWithoutParams(e) {
        return e.split("?")[0];
      }
      static paramsFromUrl(e) {
        if (!e) return new URLSearchParams();
        const t = e instanceof URL ? e.href : e;
        if (!t.includes("?")) return new URLSearchParams();
        const n = t.split("?");
        if (n.length <= 1) return new URLSearchParams();
        const r = n[1];
        return new URLSearchParams(r);
      }
      static urlParametersWithoutDuplicates(e) {
        const t = Array.from(e.keys()),
          n = new Map();
        t.forEach((t) => {
          const r = e.getAll(t);
          n.set(t, r[r.length - 1]);
        });
        const r = new URLSearchParams();
        return (
          n.forEach((e, t) => {
            r.append(t, e);
          }),
          r
        );
      }
      static getUtmParameters() {
        var e, t, n, r, l, a;
        const s = "hQwK21wXxR",
          u = "::",
          c = new URLSearchParams(window.location.search);
        function d(e) {
          const t = c.get(e);
          if (null != t && "null" !== t && "undefined" !== t && "" !== t)
            return t;
          const n = localStorage.getItem(e);
          if (!n) return "";
          const r = localStorage.getItem(m(e));
          return !r || new Date(r) < new Date()
            ? (localStorage.removeItem(e), localStorage.removeItem(m(e)), "")
            : n;
        }
        function v(e, t) {
          return e.join(t);
        }
        function p(e) {
          const t = (function () {
            var e, t, n;
            const r =
              null !==
                (t =
                  null !== (e = localStorage.getItem("lead")) && void 0 !== e
                    ? e
                    : localStorage.getItem("lead-google")) && void 0 !== t
                ? t
                : localStorage.getItem("lead-kwai");
            if (!r) return null;
            const l = JSON.parse(r);
            return null !== (n = null == l ? void 0 : l._id) && void 0 !== n
              ? n
              : null;
          })();
          return t ? (e.includes("jLj") ? e : `${e}jLj${t}`) : e;
        }
        const f = d("utm_term");
        let h = d("utm_content"),
          g = d("utm_medium"),
          S = d("utm_campaign"),
          b = p(d("utm_source"));
        const y = d("gclid"),
          w = d("gbraid"),
          _ = d("wbraid"),
          U = new URLSearchParams(),
          R = d("cid");
        o.isCartpanda
          ? U.set("cid", R || Math.round(1e11 * Math.random()).toString())
          : R && U.set("cid", R),
          U.set("utm_source", b),
          U.set("utm_campaign", S),
          U.set("utm_medium", g),
          U.set("utm_content", h),
          U.set("utm_term", f);
        const P = d("CampaignID"),
          k = d("adSETID"),
          I = d("CreativeID"),
          C = d("click_id"),
          E = d("pixel_id"),
          L = (e) => null != e && "" !== e;
        L(P) &&
          L(k) &&
          L(I) &&
          ((b = p("kwai")),
          (S = (null == S ? void 0 : S.includes(P)) ? S : P),
          (g = (null == g ? void 0 : g.includes(k)) ? g : k),
          (h = (null == h ? void 0 : h.includes(I))
            ? h
            : o.preventClickIdsFallback
            ? I
            : [I, C, E].join(u)),
          U.set("utm_source", b),
          U.set("utm_campaign", S),
          U.set("utm_medium", g),
          U.set("utm_content", h)),
          o.isClickBank
            ? (U.set("aff_sub1", i.UrlRebuilder.removeSpecialCharacteres(b)),
              U.set(
                "aff_sub2",
                i.UrlRebuilder.removeSpecialCharacteres(S).replace(
                  /\|(?=\d{10,}$)(?!.*\|)/,
                  "cKBk"
                )
              ),
              U.set(
                "aff_sub3",
                i.UrlRebuilder.removeSpecialCharacteres(g).replace(
                  /\|(?=\d{10,}$)(?!.*\|)/,
                  "cKBk"
                )
              ),
              U.set(
                "aff_sub4",
                i.UrlRebuilder.removeSpecialCharacteres(
                  null !==
                    (t =
                      null === (e = null == h ? void 0 : h.split(u)) ||
                      void 0 === e
                        ? void 0
                        : e[0]) && void 0 !== t
                    ? t
                    : ""
                ).replace(/\|(?=\d{10,}$)(?!.*\|)/, "cKBk")
              ),
              U.set("aff_sub5", i.UrlRebuilder.removeSpecialCharacteres(f)))
            : o.preventSubIds ||
              (U.set("subid", i.UrlRebuilder.removeSpecialCharacteres(b)),
              U.set("sid2", i.UrlRebuilder.removeSpecialCharacteres(S)),
              U.set("subid2", i.UrlRebuilder.removeSpecialCharacteres(S)),
              U.set("subid3", i.UrlRebuilder.removeSpecialCharacteres(g)),
              U.set(
                "subid4",
                i.UrlRebuilder.removeSpecialCharacteres(
                  null !==
                    (r =
                      null === (n = null == h ? void 0 : h.split(u)) ||
                      void 0 === n
                        ? void 0
                        : n[0]) && void 0 !== r
                    ? r
                    : ""
                )
              ),
              U.set("subid5", i.UrlRebuilder.removeSpecialCharacteres(S)));
        const x = d("src");
        null != x && "" !== x && U.set("src", x);
        const A = [
            b,
            S,
            g,
            3 ===
            (null !==
              (a =
                null === (l = null == h ? void 0 : h.split(u)) || void 0 === l
                  ? void 0
                  : l.length) && void 0 !== a
              ? a
              : 0)
              ? h.split(u)[0]
              : h,
            f,
          ],
          j = A.every((e) => "" === e),
          T = d("xcod"),
          $ = d("sck");
        if (o.preventXcodSck) T && U.set("xcod", T), $ && U.set("sck", $);
        else {
          const e = v(A, s),
            t = (function (e, t, n) {
              if (e.length <= 255) return e;
              const r = Math.floor(18.8);
              function l(e, t, n) {
                function l(e) {
                  return e.substring(0, r) + "...";
                }
                if (!t) return l(e);
                const i = null != n ? n : "|",
                  o = e.split(i),
                  a = o.length > 1 ? o[o.length - 1] : "";
                return `${l(
                  1 === o.length ? o[0] : o.slice(0, -1).join(i)
                )}${i}${a}`;
              }
              const [i, o, a, s, u] = e.split(n);
              return v(
                [l(i, !0, "jLj"), l(o, !0), l(a, !0), l(s, !0), l(u, !1)],
                n
              );
            })(j ? ("" !== T ? T : x) : e, 0, s);
          U.set("xcod", t), U.set("sck", t);
        }
        const O = c.get("fbclid");
        null != O &&
          "" !== O &&
          (U.set("fbclid", O),
          o.preventClickIdsFallback ||
            ((h = (null == h ? void 0 : h.includes(u))
              ? h
              : [h, O, ""].join(u)),
            U.set("utm_content", h))),
          null != y &&
            "" !== y &&
            (U.set("gclid", y),
            o.preventClickIdsFallback ||
              ((h = (null == h ? void 0 : h.includes(u))
                ? h
                : [h, y, ""].join(u)),
              U.set("utm_content", h))),
          null != w && "" !== w && U.set("gbraid", w),
          null != _ && "" !== _ && U.set("wbraid", _);
        const q = d("utm_id");
        return (
          q && U.set("utm_id", q),
          (() => {
            const e = (e) => null == e || "" === e,
              t = d("utm_source"),
              n = d("utm_medium"),
              r = d("utm_campaign"),
              l = d("utm_content"),
              i = d("utm_term"),
              o = d("gclid"),
              a = d("click_id"),
              s = d("CampaignID"),
              u = d("xcod"),
              c = d("src"),
              m = U.get("fbclid");
            return (
              e(t) &&
              e(n) &&
              e(r) &&
              e(l) &&
              e(i) &&
              e(u) &&
              e(c) &&
              e(m) &&
              e(o) &&
              e(a) &&
              e(s)
            );
          })() && U.set("utm_source", "organic"),
          (window.utmParams = U),
          U
        );
      }
      static simplifyParametersIfNecessary(e, t) {
        if (!Object.values(a).some((t) => e.includes(t))) return t;
        const n = new URLSearchParams();
        return (
          t.forEach((e, t) => {
            u.includes(t) && n.append(t, e);
          }),
          n
        );
      }
    }
    (window.paramsList = [
      "utm_source",
      "utm_campaign",
      "utm_medium",
      "utm_content",
      "utm_term",
      "xcod",
      "src",
    ]),
      (window.itemExpInDays = 7);
    const d = [
      "utm_source",
      "utm_campaign",
      "utm_medium",
      "utm_content",
      "xcod",
      "sck",
    ];
    function m(e) {
      return `${e}_exp`;
    }
    function v() {
      function e(e) {
        document.querySelectorAll("a").forEach((t) => {
          var n;
          if (
            !(
              t.href.startsWith("mailto:") ||
              t.href.startsWith("tel:") ||
              t.href.includes("#") ||
              (null === (n = null == o ? void 0 : o.ignoreClasses) ||
              void 0 === n
                ? void 0
                : n.some((e) => t.classList.contains(e)))
            )
          ) {
            if (
              ((r = t.href),
              [
                "wa.me/",
                "api.whatsapp.com/send",
                "whatsapp:",
                "link.dispara.ai/",
                "random.lailla.io/",
              ].some((e) => r.includes(e)))
            ) {
              const e = c.getUtmParameters(),
                n = i.UrlRebuilder.getAdId(e);
              return (
                (t.href = i.UrlRebuilder.randomizePhoneNumberIfNecessary(
                  t.href
                )),
                void (t.href = i.UrlRebuilder.insertAdIdInWppUrl(
                  t.href,
                  null != n ? n : ""
                ))
              );
            }
            var r;
            if (e && d.every((e) => t.href.includes(e))) return;
            (t.href = c.addUtmParametersToUrl(t.href)),
              o.replaceLinks &&
                (function (e, t) {
                  var n, r;
                  if ("true" === e.getAttribute("data-replaced-element"))
                    return;
                  if (
                    t &&
                    !(null === (n = e[t.property]) || void 0 === n
                      ? void 0
                      : n.includes(t.value))
                  )
                    return;
                  const l = document.createElement(e.tagName);
                  for (const t of e.attributes) l.setAttribute(t.name, t.value);
                  l.setAttribute("data-replaced-element", "true"),
                    (l.innerHTML = e.innerHTML),
                    null === (r = e.parentNode) ||
                      void 0 === r ||
                      r.replaceChild(l, e);
                })(t, { property: "href", value: o.replaceLinks });
          }
        });
      }
      function t(e) {
        document.querySelectorAll("form").forEach((t) => {
          var n;
          (e && d.every((e) => t.action.includes(e))) ||
            (null === (n = null == o ? void 0 : o.ignoreClasses) || void 0 === n
              ? void 0
              : n.some((e) => t.classList.contains(e))) ||
            ((t.action = c.addUtmParametersToUrl(t.action)),
            c.getUtmParameters().forEach((e, n) => {
              const r = ((l = n), t.querySelector(`input[name="${l}"]`));
              var l;
              if (r) return void r.setAttribute("value", e);
              const i = ((e, t) => {
                const n = document.createElement("input");
                return (n.type = "hidden"), (n.name = e), (n.value = t), n;
              })(n, e);
              t.appendChild(i);
            }));
        });
      }
      !(function () {
        const e = new URLSearchParams(window.location.search);
        window.paramsList.forEach((t) => {
          const n = e.get(t);
          n &&
            ((e, t) => {
              localStorage.setItem(e, t);
              const n = new Date(
                new Date().getTime() + 24 * window.itemExpInDays * 60 * 60 * 1e3
              );
              localStorage.setItem(m(e), n.toISOString());
            })(t, n);
        });
      })();
      const n = (function () {
        var e, t, n, r, l, i, a, s, u, c, d, m, v, p, f, h, g, S, b, y, w, _;
        const { fixShopifyTheme: U } = o,
          R =
            null !==
              (t =
                null ===
                  (e =
                    null === window || void 0 === window
                      ? void 0
                      : window.BOOMR) || void 0 === e
                  ? void 0
                  : e.themeName) && void 0 !== t
              ? t
              : null ===
                  (r =
                    null ===
                      (n =
                        null === window || void 0 === window
                          ? void 0
                          : window.Shopify) || void 0 === n
                      ? void 0
                      : n.theme) || void 0 === r
              ? void 0
              : r.schema_name,
          P =
            null !== (l = null == R ? void 0 : R.includes("Dropmeta")) &&
            void 0 !== l &&
            l,
          k =
            null !== (i = null == R ? void 0 : R.includes("Warehouse")) &&
            void 0 !== i &&
            i,
          I =
            null !== (a = null == R ? void 0 : R.includes("Classic®")) &&
            void 0 !== a &&
            a,
          C =
            null !== (s = null == R ? void 0 : R.includes("Tema Vision")) &&
            void 0 !== s &&
            s,
          E =
            null !== (u = null == R ? void 0 : R.includes("Waresabino")) &&
            void 0 !== u &&
            u,
          L =
            null !== (c = null == R ? void 0 : R.includes("Dawn")) &&
            void 0 !== c &&
            c,
          x =
            null !== (d = null == R ? void 0 : R.includes("Vortex")) &&
            void 0 !== d &&
            d,
          A =
            null !== (m = null == R ? void 0 : R.includes("Warepro")) &&
            void 0 !== m &&
            m,
          j =
            null !== (v = null == R ? void 0 : R.includes("Wareimadigital")) &&
            void 0 !== v &&
            v,
          T =
            null !== (p = null == R ? void 0 : R.includes("Mercado Livre")) &&
            void 0 !== p &&
            p,
          $ =
            null !== (f = null == R ? void 0 : R.includes("Tema Evolution®")) &&
            void 0 !== f &&
            f,
          O =
            null !==
              (h = null == R ? void 0 : R.includes("Evolution Enterprise")) &&
            void 0 !== h &&
            h,
          q =
            null !==
              (g = null == R ? void 0 : R.includes("Tema Sabino Vision")) &&
            void 0 !== g &&
            g,
          D =
            null !== (S = null == R ? void 0 : R.includes("Split")) &&
            void 0 !== S &&
            S,
          N =
            null !== (b = null == R ? void 0 : R.includes("WART")) &&
            void 0 !== b &&
            b,
          M =
            null !== (y = null == R ? void 0 : R.includes("Vogal")) &&
            void 0 !== y &&
            y,
          W =
            null !== (w = null == R ? void 0 : R.includes("Aurohra 2.0")) &&
            void 0 !== w &&
            w,
          F =
            null !== (_ = null == R ? void 0 : R.includes("RAWART")) &&
            void 0 !== _ &&
            _;
        return (
          U ||
          P ||
          k ||
          I ||
          C ||
          E ||
          L ||
          x ||
          A ||
          j ||
          T ||
          $ ||
          F ||
          O ||
          q ||
          D ||
          N ||
          M ||
          W
        );
      })();
      e(),
        (function () {
          const e = window.open;
          window.open = function (t, n, r) {
            var l;
            return (
              (t = c.addUtmParametersToUrl(
                null !== (l = null == t ? void 0 : t.toString()) && void 0 !== l
                  ? l
                  : ""
              )),
              e(t, n || "", r || "")
            );
          };
        })(),
        n ||
          (t(),
          (function () {
            const { body: n } = document;
            new MutationObserver((n, r) => {
              const l = (e) => {
                if (e.nodeType !== Node.ELEMENT_NODE) return !1;
                const t = e;
                return (
                  "INPUT" === t.tagName &&
                  "hidden" === (null == t ? void 0 : t.type)
                );
              };
              n.some((e) => Array.from(e.addedNodes).some(l)) || (e(!0), t(!0));
            }).observe(n, { subtree: !0, childList: !0 });
          })(),
          o.ignoreAllIframes ||
            document.querySelector('link[href="https://api.vturb.com.br"]') ||
            document.querySelectorAll("iframe").forEach((e) => {
              var t;
              Object.values(s).some((t) => e.src.includes(t)) ||
                (null === (t = null == o ? void 0 : o.ignoreClasses) ||
                void 0 === t
                  ? void 0
                  : t.some((t) => e.classList.contains(t))) ||
                (e.src = c.addUtmParametersToUrl(e.src));
            }));
    }
    const p = () => {
      v(),
        o.ignoreScriptRetry ||
          (setTimeout(v, 2e3),
          setTimeout(v, 3e3),
          setTimeout(v, 5e3),
          setTimeout(v, 9e3));
    };
    o.fastStart || "complete" === document.readyState
      ? p()
      : window.addEventListener("load", p);
  })();
})();
